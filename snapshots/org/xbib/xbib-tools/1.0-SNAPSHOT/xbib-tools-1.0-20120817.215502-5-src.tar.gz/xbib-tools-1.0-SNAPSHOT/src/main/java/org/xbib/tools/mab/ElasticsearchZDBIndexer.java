package org.xbib.tools.mab;

public class ElasticsearchZDBIndexer {
    
}
